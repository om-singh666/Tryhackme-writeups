**System Info**

```cmd
systeminfo                    # OS, patches, hostname
whoami                        # current user
whoami /priv                  # privileges (SeImpersonate = privesc)
```

**Users & Groups**

```cmd
net user                      # all local users
net user <username>           # specific user detail
net localgroup                # all groups
net localgroup administrators # who has admin
```

**Network**

```cmd
ipconfig /all                 # IP, DNS, adapter info
netstat -ano                  # open ports, active connections
```

**Processes & Software**

```cmd
tasklist                          # running processes
wmic product get name,version     # installed software + versions
```

---

**Attack Mindset:**

```
whoami /priv → SeImpersonate dikhe → Potato attack
net localgroup administrators → target users
systeminfo → old OS/missing patches → kernel exploit
wmic product → outdated software → CVE search
```

---