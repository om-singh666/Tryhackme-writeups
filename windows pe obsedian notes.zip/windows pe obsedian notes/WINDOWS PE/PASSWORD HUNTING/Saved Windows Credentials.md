Windows credentials save kar sakta hai — list dekho:

cmd

```cmd
cmdkey /list
```

Password nahi dikhega but saved user se directly command chala sakte ho:

cmd

```cmd
runas /savecred /user:admin cmd.exe
```


# MAAN LE BSDK AGAR TUJHE ISE ME ADMIN KA MIL GYA HOTA TOH RUNAS KRKE CMD.EXE JO MILTA VOH NT AUTHO KA HOTA ADMIN KE SAVED CRED SE HO RHA HAI
