PuTTY proxy credentials registry mein cleartext store karta hai:

cmd

```cmd
reg query HKEY_CURRENT_USER\Software\SimonTatham\PuTTY\Sessions\ /f "Proxy" /s
```