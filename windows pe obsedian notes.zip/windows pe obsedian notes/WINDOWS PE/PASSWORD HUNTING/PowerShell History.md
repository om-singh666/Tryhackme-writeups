
PowerShell har command save karta hai — agar kisi ne password command mein type kiya toh wahan milega.


```cmd
type %userprofile%\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadline\ConsoleHost_history.txt
```