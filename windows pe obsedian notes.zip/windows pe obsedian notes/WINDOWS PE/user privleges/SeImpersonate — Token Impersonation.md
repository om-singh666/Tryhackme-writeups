**Access Token kya hai?**  
Windows mein har process ke paas ek **Access Token** hota hai. Yeh token define karta hai ki process **kya kar sakta hai** (permissions). Token mein user account, groups, aur privileges store hote hain.

**Token Types:**

| Token Type                | Privilege | Example                                          |
| ------------------------- | --------- | ------------------------------------------------ |
| **User Token**            | Limited   | Normal user (`jdoe`)                             |
| **Local Service Token**   | Medium    | Service account (`NT AUTHORITY\Local Service`)   |
| **Network Service Token** | Medium    | Network service (`NT AUTHORITY\Network Service`) |
| **SYSTEM Token**          | Highest   | `NT AUTHORITY\SYSTE`                             |
Jab koi Windows pe login karta hai — usse ek **access token** milta hai. Ye token = us user ki identity card.

SeImpersonate privilege = **doosre user ka token borrow kar sako matlab aagr om ek hacker hai usne kisi site pe windows pe inital acces liya aur dekha ki jis creds se usene inital acces liya hai uspe seimperosnate set hai iska mtlb yeh creds wala user dusre ke tokkens use kr kr nayi services chala skta hai aur voh services usi borrowed wale user ki privleefe ke sath hogi mtlb maan lo jai ke tokken borror kiya toh jai ke privllege ke shelll agar admin ka brorrow kiya toh admin ka shell**

Service accounts (Local Service, Network Service, IIS AppPool) ko ye privilege by default milta hai — taaki wo connecting users ke behalf pe kaam kar sakein.

**Vulnerability:**  
Agar tu kisi service account ka shell le le — aur us account ke paas SeImpersonate ho — tu SYSTEM token steal kar sakta hai.



**Background (Access Tokens & The Superpower):** Windows mein har user aur process ke paas ek "Access Token" hota hai (jaise ek Digital ID Card). Jab koi software (jaise IIS Web Server ya MSSQL Database) chalta hai, toh usko kai baar network par doosre users ki tarah act karna padta hai. Iske liye Windows in service accounts ko ek special superpower (privilege) deta hai: **`SeImpersonatePrivilege`** ya **`SeAssignPrimaryTokenPrivilege`**.

Agar aapke current shell ke paas `SeImpersonatePrivilege` hai, iska matlab aapka account allowed hai ki agar uske haath mein kisi doosre user ka ID card (Token) lag jaye, toh wo uski identity le (impersonate kar) sakta hai.

**Hacker ka logic (The Trap):** Agar aapke paas yeh privilege hai, toh aap kya karte ho? Aap Windows OS ke andar ek fake service/listener (jaal) banate ho, aur Windows ki default high-privileged services (jo `SYSTEM` par chalti hain) ko majboor karte ho ki wo aapki fake service par aakar authenticate karein.

Jaise hi `SYSTEM` account aapke trap par connect hota hai, wo apna "Master ID Card" (SYSTEM Token) network/pipe par bhejta hai. Aapka exploit us token ko steal (catch) kar leta hai aur `SeImpersonatePrivilege` ka use karke us "SYSTEM ID Card" ko pehen kar aapka `reverse.exe` chala deta hai! Boom, aap SYSTEM ban gaye!